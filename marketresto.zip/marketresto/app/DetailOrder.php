<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetailOrder extends Model
{
    //
//    protected $table = 'detail_order';
//    protected $fillable = [
//        'id_order',
//        'id_menu',
//        'qty',
//        'harga',
//        'discount',
//        'catatan',
//    ];

//    public function order(){
//        return $this->belongsTo('App\Order','id_order');
//
//    }
//    public function menu(){
//        return $this->hasMany('App\Menu','id_menu');
//    }


}

