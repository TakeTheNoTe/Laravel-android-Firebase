<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class MenuResource extends JsonResource
{


    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        return [
            'id' => $this->id,
            'id_restoran' => $this->id_restoran,
            'id_kategori'=> $this->id_kategori,
            'id_satuan'=> $this->id_satuan,
            'menu_kategori' => $this->kategori->kategori_nama,
            'menu_satuan' => $this->satuan->satuan_nama,
            'menu_nama'=> $this->menu_nama,
            'menu_foto'=> $this->menu_foto,
            'menu_harga'=> $this->menu_harga,
            'menu_deskripsi'=> $this->menu_deskripsi,
            'menu_ketersediaan'=> $this->menu_ketersediaan,
            'menu_discount'=> $this->menu_discount,
            'menu_jumlah_favorit' => $this->favorit->count(),
            'menu_favorit' => $this->favorit->where('id_konsumen','=',$this->kons)->count(),


        ];
    }




}
