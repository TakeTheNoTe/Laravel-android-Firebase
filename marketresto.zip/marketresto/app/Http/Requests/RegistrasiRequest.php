<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class RegistrasiRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            'restoran_nama' => 'required|string|max:300',
            'restoran_phone' => 'required|max:14|unique:restoran,restoran_phone',
            'restoran_email'=> 'required',
            'restoran_alamat'=> 'required',
            'restoran_deskripsi'=> 'required',
            'restoran_foto' => 'required|image|max:500|mimes:jpeg,jpg,bmp,png',
            'restoran_pemilik_nama'=> 'required',
            'restoran_pemilik_email'=> 'required',
            'restoran_pemilik_phone'=> 'required|max:14',
            'restoran_delivery'=> 'required|in:gratis,flat',
            'restoran_delivery_jarak'=> 'required|integer',
            'restoran_delivery_minimum'=> 'required|integer',
            'restoran_pajak_pb_satu'=> 'required|integer',
            'restoran_kategori' => 'required',
        ];
    }
//|unique:kurir,kurir_phone'
}
