<?php

namespace App\Http\Controllers\Marketresto;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PageController extends Controller
{
    //


    public function index(){
        return view('marketresto.index');
    }
    public function daftar(){
        return view('marketresto.daftar');
    }
    public function contact(){
        return view('marketresto.contact');
    }

}
