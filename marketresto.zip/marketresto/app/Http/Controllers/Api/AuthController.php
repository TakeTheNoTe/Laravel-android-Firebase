<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\RestoranResource;
use App\Http\Resources\KurirResource;
use App\Kurir;
use App\Restoran;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Konsumen;
use App\Http\Resources\KonsumenResource;

class AuthController extends Controller
{



    public function marketresto($phone){
        $konsumen = Konsumen::where('konsumen_phone',$phone)->first();
        if ($konsumen) {
            return new KonsumenResource($konsumen);
        } else {
            return [
                'value' => '0',
                'message' => 'Nomor Ponsel Tidak Terdaftar',
            ];
        }


    }


    public function restopartner($phone){
        $restoran = Restoran::where('restoran_phone',$phone)->first();
        if ($restoran) {
            $data = new RestoranResource($restoran);
            if($restoran->restoran_status == "aktif") {
                return [
                    "value" => "1",
                    "message" => "succes",
                    "tipe" => "restoran",
                    "restoran" => $restoran,
                ];
            }else{
                return [
                    'value' => '0',
                    'message' => 'Restoran dalam tahap review',
                ];
            }
        } else{
            $kurir = Kurir::where('kurir_phone',$phone)->first();
            if($kurir){

                $data =  new KurirResource($kurir);
                if($kurir->restoran->restoran_status == "aktif") {
                    return [
                        "value" => "1",
                        "message" => "succes",
                        "tipe" => "kurir",
                        "kurir" => $kurir,
                    ];
                }else{
                    return [
                        'value' => '0',
                        'message' => 'Harap hubungi restoran anda',
                    ];
                }


            }else{
                return [
                    'value' => '0',
                    'message' => 'Nomor Ponsel Tidak Terdaftar',
                ];
            }
        }


    }

}
