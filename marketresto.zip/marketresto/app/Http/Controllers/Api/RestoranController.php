<?php

namespace App\Http\Controllers\Api;

use App\Http\Resources\LaporanResource;
use App\Http\Resources\MenuResource;
use App\Http\Resources\RestoranCollection;
use App\Http\Resources\RestoranResource;
use App\Konsumen;
use App\Menu;
use App\Order;
use App\Restoran;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;

class RestoranController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        //ambil parameter lokasi user
        $lat = $request->input('lat');
        $long = $request->input('long');
        $id_konsumen = $request->input('id_konsumen');


        //ambil satu restoran untuk cart
        if ($request->has('id_restoran')){
            $id_restoran =  $request->input('id_restoran');

            $resto =$this->get_restaurant($lat,$long,$id_restoran);
            $konsumen =  Konsumen::findOrFail($id_konsumen);
            $saldo =  $konsumen->konsumen_balance;

            if($resto->count()>0) {
                $restoran = new RestoranResource($resto);
                $menu = $restoran->menu->where('menu_delete',0);
                $menu_item = MenuResource::collection($menu);
                return [
                    'value' => '1',
                    'message' => 'Restoran Ditemukan',
                    'konsumen_balance' => $saldo,
                    'data' => $restoran,
                    'menu' => $menu_item,


                ];
            }else{
                return [
                    'value' => '0',
                    'message' => 'Restoran Tidak Ditemukan',
                ];
            }


        }else if($request->has('cari')) {
            $key = $request->input('cari');

            //cari restoran terdekat
            $re =$this->get_restaurant_near($lat,$long,300);


            //ubah kearray
            $koleksi = $re->toArray();
            $items = array();

            $menu = array();
            foreach ($koleksi as $resto){
                //ambil restoran yang memungkinkan untuk mengantarkan
                if ($resto['distance'] < $resto['restoran_delivery_jarak']){
                    $Restoran = Restoran::findOrFail($resto['id']);

                    //ambil restoran yang memiliki menu saja
                    if($Restoran->menu->where('menu_delete',0)->count() > 0) {
                        //set id restoran yang sudah di seleksi
                        $items[] = $resto['id'];
                        //get menu
                        $tem=$Restoran->menu;
                        for ($x = 0; $x < $Restoran->menu->count(); $x++) {
                            $menu[] = $tem[$x];

                        }

                    }

                }
            }

            //ambil data restoran berdasarkan restoran yang memungkinkan
            $restoran_coll = $re->whereIn('id',$items);


//            $x =collect($restoran_coll)->filter(function ($item) use ($key) {
//                // replace stristr with your choice of matching function
//                return false !== strisr($item->restoran_nama, $key);
//            });

            //mb_strpos

            $restoranCollection = $restoran_coll->reject(function($element) use ($key) {
                return stripos($element->restoran_nama, $key) === false;
            });
            $x = collect($menu);
            $menuCollection = $x->reject(function($element) use ($key) {
                return stripos(strtolower($element->menu_nama), $key) === false;
            });

            //jika restoran memungkinkan besar dari 0 , tampilkan seluruh restoran
            if($restoranCollection->count()> 0 || $menuCollection->count() > 0){
                $b = RestoranResource::collection($restoranCollection);
                $c =  $b->sortByDesc('restoran_order');
                $hasilMenu = MenuResource::collection($menuCollection);
                $hasilRestoran = new RestoranCollection($c);

                return [
                    'value' => '1',
                    'message' => 'succes',
                    'restoran' => $hasilRestoran,
                    'menu' => $hasilMenu,
                ];


                //jika tidak ada restoran memungkinkan
            }else{
                return [
                    'value' => '0',
                    'message' => 'Restoran Tidak Ditemukan',
                ];
            }

        }else{
            //cari restoran terdekat
            $re =$this->get_restaurant_near($lat,$long,300);


            //ubah kearray
            $koleksi = $re->toArray();
            $items = array();
            foreach ($koleksi as $resto){
                //ambil restoran yang memungkinkan untuk mengantarkan
                if ($resto['distance'] < $resto['restoran_delivery_jarak']){
                    $Restoran = Restoran::findOrFail($resto['id']);
                    //ambil restoran yang memiliki menu saja
                    if($Restoran->menu->where('menu_delete',0)->count() > 0) {
                        //set id restoran yang sudah di seleksi
                        $items[] = $resto['id'];
                    }
                }
            }

            //ambil data restoran berdasarkan restoran yang memungkinkan
            $restoran_coll = $re->whereIn('id',$items);

            //jika restoran memungkinkan besar dari 0 , tampilkan seluruh restoran
            if($restoran_coll->count()>0){
                $b = RestoranResource::collection($restoran_coll);
            //    $c =  $b->sortByDesc('restoran_distace2');
                return new RestoranCollection($b);

                //jika tidak ada restoran memungkinkan
            }else{
                return [
                    'value' => '0',
                    'message' => 'Restoran Tidak Ditemukan',
                ];
            }
        }
    }


    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $restoran = Restoran::findOrFail($id);


        if($restoran != null){
             return new RestoranResource($restoran);
        }else{
            return array('not found');
        }

    }


    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //

        $restoran = Restoran::findOrFail($id);
        if($restoran->update($request->all())) {
            // return new KonsumenResource($konsumen);
            return [
                'value' => '1',
                'message' => 'Berhasil Update',
                'resto' => $restoran,
            ];
        }else{
            return [
                'value' => '0',
                'message' => 'Gagal Update',
            ];
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    public function laporan($id)
    {
        //
        $now = Carbon::now();
        $month = $now->month;
        $year = $now->year;
        $order = Order::where('id_restoran', $id)
            ->whereDate('created_at', '=', $now)
            ->get();
        $orderMonth = Order::where('id_restoran', $id)
            ->whereYear('created_at', '=', $year)
            ->whereMonth('created_at', '=', $month)
            ->get();

        $menu = Menu::where('id_restoran', $id)
            ->where('menu_delete','0')
            ->get();

        $a = LaporanResource::collection($menu);


        return[
            'jumlah_order' =>$order->where('order_status','Proses')->count(),
            'jumlah_pengantaran' =>$order->where('order_status','Pengantaran')->count(),
            'jumlah_selesai' =>$order->where('order_status','Selesai')->count(),
            'jumlah_batal' =>$order->where('order_status','Batal')->count(),
            'order_month_selesai' => $orderMonth->where('order_status','Selesai')->count(),
            'order_month_batal' => $orderMonth->where('order_status','Batal')->count(),
            'menu' => $a,
        ];

    }






    public function get_restaurant_near($latitude, $longitude, $radius){

        $offers = Restoran::select('restoran.*')
            ->selectRaw('( 6371* acos( cos( radians(?) ) *
                           cos( radians( restoran_latitude ) )
                           * cos( radians( restoran_longitude ) - radians(?)
                           ) + sin( radians(?) ) *
                           sin( radians( restoran_latitude ) ) )
                         ) AS distance', [$latitude, $longitude, $latitude])
            ->havingRaw("distance <?",[$radius])
            ->where("restoran_status" , "=" , "aktif")
            ->where("restoran_balance" , ">" , 50)
            ->orderBy('distance')
            ->get();

        return $offers;
    }


    public function get_restaurant($latitude, $longitude, $id){

        $offers = Restoran::select('restoran.*')
            ->selectRaw('( 6371* acos( cos( radians(?) ) *
                           cos( radians( restoran_latitude ) )
                           * cos( radians( restoran_longitude ) - radians(?)
                           ) + sin( radians(?) ) *
                           sin( radians( restoran_latitude ) ) )
                         ) AS distance', [$latitude, $longitude, $latitude])
            ->where("restoran_status" , "=" , "aktif")
            ->where("id" , "=",$id)
            ->where("restoran_balance" , ">" , 50)
            ->first();

        return $offers;
    }
}
