<?php

namespace App\Http\Controllers\Admin;

use App\Mail\TerimaMailable;
use App\Mail\TolakMailable;
use App\Restoran;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Mail;

class RegistrasiController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     *
     */

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

        $restoran_list = Restoran::all()->where('restoran_status','==','review');

        return view('admin.registrasi',compact('restoran_list'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $restoran = Restoran::findOrfail($id);
        $restoran->restoran_status = $request->restoran_status;
        $restoran->update();
        $email = $restoran->restoran_pemilik_email;


        if ($request->restoran_status == 'aktif'){

          //  Mail::to($email)->send(new TerimaMailable($restoran));
        }else{
           // Mail::to($email)->send(new TolakMailable($restoran));
        }

        return redirect('admin/registrasi');


    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
