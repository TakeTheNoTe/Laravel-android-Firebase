<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Restoran extends Model
{
    //
    protected $table = 'restoran';

    protected $fillable = [
        'restoran_nama',
        'restoran_phone',
        'restoran_email',
        'restoran_deskripsi',
        'restoran_alamat',
        'restoran_oprasional',
        'restoran_latitude',
        'restoran_longitude',
        'restoran_foto',
        'restoran_pemilik_nama',
        'restoran_pemilik_email',
        'restoran_pemilik_phone',
        'restoran_balance',
        'restoran_delivery',
        'restoran_delivery_tarif',
        'restoran_delivery_jarak',
        'restoran_delivery_minimum',
        'restoran_pajak_pb_satu',
        'restoran_status',
        'token'

    ];

    public function kategori(){
        return $this->belongsToMany('App\Kategori','restoran_kategori','id_restoran','id_kategori')->withTimestamps();
    }

    public function  menu(){
        return $this->hasMany('App\Menu','id_restoran');
    }

    public function  kurir(){
        return $this->hasMany('App\Kurir','id_restoran');
    }

    public function  order(){
        return $this->hasMany('App\Order','id_restoran');
    }

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'updated_at'
    ];
}
