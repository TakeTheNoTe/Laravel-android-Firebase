@extends('marketresto.layout.template')




@section('main')
    <section class="contact-page inner-page">
    <div class="container">

                @include('marketresto.layout.flash_mesage')

    </div>
    </section>
    @stop