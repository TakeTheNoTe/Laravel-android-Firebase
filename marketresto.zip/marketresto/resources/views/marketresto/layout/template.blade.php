<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="icon" href="#">
    <title>Inkubator Teknik Informatika|MarketResto</title>
    <!-- Bootstrap core CSS -->
    <link href="{{asset('marketresto/css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="{{asset('marketresto/css/font-awesome.min.css')}}" rel="stylesheet">
    <link href="{{asset('marketresto/css/animsition.min.css')}}" rel="stylesheet">
    <link href="{{asset('marketresto/css/animate.css')}}" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="{{asset('marketresto/css/style.css')}}" rel="stylesheet">
<link href="{{asset('vendors/bower_components/select2/dist/css/select2.min.css')}}" rel="stylesheet" >
<link href="{{asset('vendors/bower_components/multiselect/css/multi-select.css')}}" rel="stylesheet" >

</head>


<body class="home">
<div class="site-wrapper animsition" data-animsition-in="fade-in" data-animsition-out="fade-out">
    @include('marketresto.layout.navigation')
    <div class="page-wrapper">
    @yield('main')





    @include('marketresto.layout.footer')
    </div>
</div>
<!--/end:Site wrapper -->
<!-- Bootstrap core JavaScript
================================================== -->

<script src="{{asset('marketresto/js/jquery.min.js')}}"></script>
<script src="{{asset('marketresto/js/tether.min.js')}}"></script>
<script src="{{asset('marketresto/js/bootstrap.min.js')}}"></script>
<script src="{{asset('marketresto/js/animsition.min.js')}}"></script>
<script src="{{asset('marketresto/js/bootstrap-slider.min.js')}}"></script>
<script src="{{asset('marketresto/js/jquery.isotope.min.js')}}"></script>
<script src="{{asset('marketresto/js/headroom.js')}}"></script>
@yield('src')


<script src="{{asset('marketresto/js/foodpicky.js')}}"></script>
<script src="{{asset('admin/dist/js/form-advance-data.js')}}"></script>

<script src="{{asset('admin/dist/js/init.js')}}"></script>

<script src="{{asset('vendors/bower_components/select2/dist/js/select2.full.min.js')}}"></script>
<script src="{{asset('vendors/bower_components/multiselect/js/jquery.multi-select.js')}}"></script>




</body>

</html>