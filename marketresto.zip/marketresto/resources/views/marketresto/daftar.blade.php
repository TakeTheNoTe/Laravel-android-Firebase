@extends('marketresto.layout.template')

@section('main')

    <div class="inner-page-hero bg-image space-md" data-image-src="{{asset('marketresto/images/bundo-kim-500838-unsplash.jpg')}}">
        <div class="container text-xs-center m-b-20">
            <h1 class="font-white">Bergabung Bersama MarketResto</h1>
            <p class="font-white">Temukan konsumen dan tingkatkan potensi usaha anda</p>
        </div>
    </div>
    <!-- end:Inner page hero -->
    <div class="pricing-page">
        <div class="container">
            <div class="row">
                <div class="col-md-4 offset-md-4 col-sm-4">
                    <div class="pricing-box">
                           <span class="price">
                           <span class="currency">Rp</span>50</span>
                        <h2>Best Plan</h2>
                        <p>Hanya Rp50 Untuk Setiap Pesanan</p>
                        <ul data-cloneable="" data-group="" class="">
                            <li>Tanpa biaya Pendaftaran</li>
                            <li>Tanpa Biaya Bulanan</li>
                            <li>Tanpa Batas Pesanan</li>
                            {{--<li>Gain exposure</li>--}}
                        </ul>
                        <div data-group=""> <a href="{{url('/register/create')}}" class="btn theme-btn">Daftar Sekarang</a> </div>
                    </div>
                </div>
                {{--<div class="col-md-5 col-sm-6">--}}
                    {{--<div class="pricing-box">--}}
                           {{--<span class="price">--}}
                           {{--<span class="currency">Rp</span>20000</span>--}}
                        {{--<h2>Premium plan</h2>--}}
                        {{--<p>Sign up for premium plan</p>--}}
                        {{--<ul data-cloneable="" data-group="" class="">--}}
                            {{--<li>No joining fees</li>--}}
                            {{--<li>Unlimited orders per month</li>--}}
                            {{--<li>Get noticed</li>--}}
                            {{--<li>Gain exposure</li>--}}
                        {{--</ul>--}}
                        {{--<div data-group=""> <a href="{{url('/register/create')}}" class="btn theme-btn">Sign up now</a> </div>--}}
                    {{--</div>--}}
                {{--</div>--}}
            </div>
            <!-- end:row -->
            <div class="row pricing-faq m-t-30">
                <div class="col-md-5 offset-md-1 col-sm-6" data-cloneable="">
                    <div>
                        <h3>Apa itu akun?</h3>
                        <p>Dengan akun pengguna, Anda dapat mengakses aplikasi RestoPartner untuk memanajemen restoran dan menerima pesanan  </p>
                    </div>
                    <div>
                        <h3>Apakah ada biaya?</h3>
                        <p>Anda akan dikenakan biaya Rp50 untuk setiap pesanan yang di ambil dari saldo Resto-Pay Anda</p>
                    </div>
                    <div>
                        <h3>Metode pembayaran apa yang diterima?</h3>
                        <p>Transaksi kepada pelanggan dapat dilakukan dengan uang tunai atau melalui pembayaran Resto-Pay</p>
                    </div>
                </div>
                <div class="col-md-5 col-sm-6" data-cloneable="">
                    <div>
                        <h3>Bisakah saya mengatur beberapa usaha dalam satu akun?</h3>
                        <p>Saat ini Anda hanya dapat mengatur satu usaha dalam satu akun, kami akan terus meningkatkan layanan kami</p>
                    </div>
                    <div>
                        <h3>Bagaimana dengan pembayaran Resto-Pay?</h3>
                        <p>Tidak ada perbedaan jumlah yang dibayar dengan transaksi tunai, kemudahan tanpa uang kembali</p>
                    </div>
                    <div>
                        <h3>Apa dukungan kami untuk anda?</h3>
                        <p>Kami berusaha meningkatkan potensi usaha Anda dan menemukan konsumen disekitar Anda, kami maju bersama Anda</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- end:Container -->
    </div>

@stop