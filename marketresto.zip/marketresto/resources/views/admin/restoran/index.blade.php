@extends('admin.layout.base_template_admin')

@section('src')
    <link href="{{ asset('vendors/bower_components/datatables.net-responsive/css/responsive.dataTables.min.css') }}" rel="stylesheet" type="text/css"/>
    @stop

<?php

function convert_to_rupiah($angka)
{
    $agk =   substr($angka, 0, -3);
    return       'Rp. '.strrev(implode('.',str_split(strrev(strval($agk)),3)));
}


?>

@section('main')

    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark">Registrasi Baru</h5>
        </div>
        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="index.html">Dashboard</a></li>
                <li><a href="#"><span>speciality pages</span></a></li>
                <li class="active"><span>blank page</span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>



    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h5 class="txt-dark">Daftar Restoran Baru</h5>
                    </div>

                    <div class="clearfix"></div>
                </div>

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="">
                                @if($restoran_list->count() > 0)
                                <table id="myTable1" class="table table-hover display  pb-30" >
                                    <thead>
                                    <tr>
                                        <th data-sort-initial="true" data-toggle="true">ID</th>
                                        <th>tgl</th>
                                        <th >Nama Restoran</th>
                                        <th data-sorting="false">Foto</th>
                                        <th>Phone</th>
                                        <th data-sorting="false">Jumlah Pesanan</th>
                                        <th data-sorting="false">Jumlah Pesanan Selesai</th>
                                        <th data-sorting="false">Jumlah Pesanan Batal</th>
                                        <th>Email</th>
                                        <th data-sorting="false" data>Alamat</th>
                                        <th data-sorting="false">Deskripsi</th>
                                        <th data-sorting="false">Tipe Delivery</th>
                                        <th data-sorting="false"> Tarif Delivery</th>
                                        <th data-sorting="false">Minimum Order</th>
                                        <th data-sorting="false">Jarak Maksimum</th>
                                        <th data-sorting="false">Pajak PB1</th>
                                        <th data-sorting="false">Tipe Menu</th>

                                        <th></th>
                                    </tr>
                                    </thead>
                                    {{--<tfoot>--}}
                                    {{--<tr>--}}
                                        {{--<th>ID</th>--}}
                                        {{--<th>Tgl</th>--}}
                                        {{--<th>Nama Restoran</th>--}}
                                        {{--<th>Foto</th>--}}
                                        {{--<th>Phone</th>--}}
                                        {{--<th>Jumlah Pesanan</th>--}}
                                        {{--<th>Jumlah Pesanan Selesai</th>--}}
                                        {{--<th>Jumlah Pesanan Batal</th>--}}
                                        {{--<th>Email</th>--}}
                                        {{--<th>Alamat</th>--}}
                                        {{--<th>Deskripsi</th>--}}
                                        {{--<th>Tipe Delivery</th>--}}
                                        {{--<th>Tarif Delivery</th>--}}
                                        {{--<th>Minimum Order</th>--}}
                                        {{--<th>Jarak Maksimum</th>--}}
                                        {{--<th>Tipe Menu</th>--}}

                                        {{--<th></th>--}}
                                    {{--</tr>--}}
                                    {{--</tfoot>--}}
                                    <tbody>
                                    <?php foreach ($restoran_list as $restoran):?>


                                    @csrf
                                    <tr>
                                        <td>{{$restoran->id}}</td>
                                        <td>{{$restoran->created_at->format('d/m/Y H:m:s')}}</td>
                                        <td><strong>{{$restoran->restoran_nama}}</strong></td>
                                        <td><img src="{{asset('fotorestoran/'.$restoran->restoran_foto)}}" alt="{{$restoran->restoran_foto}}" width="70" height="95"></td>
                                        <td>+{{$restoran->restoran_phone}}</td>
                                        <td>{{$restoran->order->count()}}</td>
                                        <td>{{$restoran->order->where('order_status','selesai')->count()}}</td>
                                        <td>{{$restoran->order->where('order_status','batal')->count()}}</td>
                                        <td>{{$restoran->restoran_email}}</td>
                                        <td>{{$restoran->restoran_alamat}}</td>
                                        <td>{{$restoran->restoran_deskripsi}}</td>

                                        <td> @if($restoran->restoran_delivery == 'gratis')
                                                <span class="label label-warning">{{$restoran->restoran_delivery}}</span>
                                             @else
                                                <span class="label label-success">{{$restoran->restoran_delivery}}</span>
                                            @endif
                                        </td>
                                        <td>@if($restoran->restoran_delivery_tarif == 0)
                                               Gratis </span>
                                            @else
                                            <?php echo convert_to_rupiah($restoran->restoran_delivery_tarif)?>
                                            @endif</td>
                                        <td><?php echo convert_to_rupiah($restoran->restoran_delivery_minimum)?></td>
                                        <td>{{$restoran->restoran_delivery_jarak}}</td>
                                        <td>@if($restoran->restoran_pajak_pb_satu == 0)
                                                Tidak dipungut pajak </span>
                                            @else
                                                {{$restoran->restoran_pajak_pb_satu}} %
                                            @endif</td>
                                        <td>
                                            @foreach($restoran->kategori as $kategori)
                                                <strong><span>{{$kategori->kategori_nama}},</span></strong>
                                            @endforeach
                                        </td>

                                        <td>


                                            <form action="{{ route('menu', $restoran->id) }}" method="GET" style ='float: left; padding-top: 30px' >
                                                {{ csrf_field() }}
                                                <button type="submit"  class="btn btn-success" >Detail Menu</button>
                                            </form>

                                            {{--<form action="{{ route('updateRegistrasi', $restoran->id) }}" method="POST" style ='float: left;padding-top: 30px' >--}}
                                                {{--{{ csrf_field() }}--}}
                                                {{--{{ method_field('PATCH') }}--}}
                                                {{--<input type="hidden" name="restoran_status" value="tolak">--}}
                                                {{--<button type="submit" class="btn btn-danger" >Tolak </button>--}}
                                            {{--</form>--}}

                                        </td>
                                    </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>

                                    @else
                                <p> Tidak Ada Registrasi</p>
                                    @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

@stop





@section('js')
    <script src="{{asset('vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js')}}"></script>
    <script src="{{ asset('vendors/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>
    <script src="{{ asset('admin/dist/js/responsive-datatable-data.js')}}"></script>
    @stop
