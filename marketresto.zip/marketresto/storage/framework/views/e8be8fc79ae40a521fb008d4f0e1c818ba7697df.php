<div class="fixed-sidebar-left">
    <ul class="nav navbar-nav side-nav nicescroll-bar">
        <li class="navigation-header">
            <span>Main</span>
            <hr/>
        </li>
        <li>
            <a href="<?php echo e(url('/admin')); ?>" data-toggle="collapse" data-target="#dashboard_dr"><div class="pull-left"><i class="ti-dashboard mr-20"></i><span class="right-nav-text">Dashboard</span></div><div class="clearfix"></div></a>
        </li>
        <li>
            <a href="<?php echo e(url('/admin/registrasi')); ?>" data-toggle="collapse" data-target="#ecom_dr"><div class="pull-left"><i class="ti-id-badge   mr-20"></i><span class="right-nav-text">Registrasi</span></div><div class="clearfix"></div></a>
        </li>
        <li>
            <a href="<?php echo e(url('/admin/rekomendasi')); ?>" data-toggle="collapse" data-target="#ecom_dr"><div class="pull-left"><i class="ti-announcement   mr-20"></i><span class="right-nav-text">Rekomendasi</span></div><div class="clearfix"></div></a>
        </li>
        <li>
            <a href="<?php echo e(url('/admin/contact')); ?>" data-toggle="collapse" data-target="#ecom_dr"><div class="pull-left"><i class="ti-comments    mr-20"></i><span class="right-nav-text">Pesan</span></div><div class="clearfix"></div></a>
        </li>
        <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#app_dr"><div class="pull-left"><i class="ti-wallet  mr-20"></i><span class="right-nav-text">Resto-Pay </span></div><div class="pull-right"><i class="ti-angle-down"></i></div><div class="clearfix"></div></a>
            <ul id="app_dr" class="collapse collapse-level-1">
                <li>
                    <a href="<?php echo e(url('/admin/topup')); ?>">Top Up</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/admin/refound')); ?>">Refound</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/admin/riwayat_restopay')); ?>">Riwayat</a>
                </li>
                
                    
                

            </ul>
        </li>
        <li class="navigation-header mt-20">
            <span>Master</span>
            <hr/>
        </li>
        <li>
            <a href="javascript:void(0);" data-toggle="collapse" data-target="#ui_dr"><div class="pull-left"><i class="ti-server   mr-20"></i><span class="right-nav-text">Data Master</span></div><div class="pull-right"><i class="ti-angle-down "></i></div><div class="clearfix"></div></a>
            <ul id="ui_dr" class="collapse collapse-level-1 two-col-list">
                <li>
                    <a href="<?php echo e(url('/admin/kategori')); ?>">Kategori</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/admin/restoran')); ?>">Restoran</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/admin/konsumen')); ?>">Konsumen</a>
                </li>
                <li>
                    <a href="<?php echo e(url('/admin/satuan')); ?>">Satuan</a>
                </li>


            </ul>
        </li>
        <li>
            <a href="<?php echo e(url('/admin/order')); ?>" data-toggle="collapse" data-target="#comp_dr"><div class="pull-left"><i class="ti-agenda   mr-20"></i><span class="right-nav-text">Order</span></div><div class="clearfix"></div></a>
        </li>
        
            
            
        


    </ul>
</div>