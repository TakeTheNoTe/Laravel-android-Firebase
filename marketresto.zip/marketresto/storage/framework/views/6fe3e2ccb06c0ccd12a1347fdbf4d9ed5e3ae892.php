<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <title>Admintres I Fast build Admin dashboard for any platform</title>
    <meta name="description" content="Admintres is a Dashboard & Admin Site Responsive Template by hencework." />
    <meta name="keywords" content="admin, admin dashboard, admin template, cms, crm, Admintres Admin, Admintresadmin, premium admin templates, responsive admin, sass, panel, software, ui, visualization, web app, application" />
    <meta name="author" content="hencework"/>

    <!-- Favicon -->
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Data table CSS -->
    <link href="<?php echo e(asset('vendors/bower_components/datatables/media/css/jquery.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>

    <!-- Custom CSS -->
    <link href="<?php echo e(asset('admin/dist/css/style.css')); ?>" rel="stylesheet" type="text/css">
</head>

<body>
<!--Preloader-->
<div class="preloader-it">
    <div class="la-anim-1"></div>
</div>
<!--/Preloader-->
<div class="wrapper theme-2-active navbar-top-light">
    <!-- Top Menu Items -->
    <?php echo $__env->make('admin.navigation_top', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Top Menu Items -->

    <!-- Left Sidebar Menu -->
    <?php echo $__env->make('admin.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <!-- /Left Sidebar Menu -->

    <!-- Main Content -->
    <div class="page-wrapper">
        <div class="container">

            <?php echo $__env->yieldContent('main'); ?>


            <!-- Footer -->
            <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- /Footer -->
        </div>
    </div>
    <!-- /Main Content -->

</div>
<!-- /#wrapper -->

<!-- JavaScript -->

<!-- jQuery -->
<script src="<?php echo e(asset('vendors/bower_components/jquery/dist/jquery.min.js')); ?>"></script>

<!-- Bootstrap Core JavaScript -->
<script src="<?php echo e(asset('vendors/bower_components/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>

<!-- Data table JavaScript -->
<script src="<?php echo e(asset('vendors/bower_components/datatables/media/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/dist/js/dataTables-data.js')); ?>"></script>

<!-- Slimscroll JavaScript -->
<script src="<?php echo e(asset('admin/dist/js/jquery.slimscroll.js')); ?>"></script>

<!-- Owl JavaScript -->
<script src="<?php echo e(asset('vendors/bower_components/owl.carousel/dist/owl.carousel.min.js')); ?>"></script>

<!-- Switchery JavaScript -->
<script src="<?php echo e(asset('vendors/bower_components/switchery/dist/switchery.min.js')); ?>"></script>

<!-- Fancy Dropdown JS -->
<script src="<?php echo e(asset('admin/dist/js/dropdown-bootstrap-extended.js')); ?>"></script>

<!-- Init JavaScript -->
<script src="<?php echo e(asset('admin/dist/js/init.js')); ?>"></script>


</body>

</html>
