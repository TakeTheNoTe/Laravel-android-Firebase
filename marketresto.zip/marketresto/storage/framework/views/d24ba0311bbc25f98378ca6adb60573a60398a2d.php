<!-- Featured restaurants ends -->
<section class="app-section">
    <div class="app-wrap">
        <div class="container">
            <div class="row text-img-block text-xs-left">
                <div class="container">
                    <div class="col-xs-12 col-sm-5 right-image text-center">
                        <figure> <img src="<?php echo e(asset('marketresto/images/app.png')); ?>" alt="Right Image" class="img-fluid"> </figure>
                    </div>
                    <div class="col-xs-12 col-sm-7 left-text">
                        <h3>Aplikasi Pengiriman Makanan Terbaik</h3>
                        <p>Sekarang Anda dapat memesan makanan dari restoran disekitar anda secara gratis dan mudah digunakan. Download MarketResto sekarang.</p>
                        <div class="social-btns">
                            
                                
                                
                            
                            <a href="#" class="app-btn android-button clearfix">
                                <div class="pull-left"><i class="fa fa-android"></i> </div>
                                <div class="pull-right"> <span class="text">Available on the</span> <span class="text-2">Play store</span> </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



<!-- start: FOOTER -->
<footer class="footer">
    <div class="container">
        <!-- top footer statrs -->
        <div class="row top-footer">
            <div class="col-xs-12 col-sm-3 footer-logo-block color-gray">
                <a href="#"> <img src="<?php echo e(asset('marketresto/images/text-logo-medium.png')); ?>" alt="Footer logo"> </a> <span>Pesan dan Antar Pesanan </span> </div>
            <div class="col-xs-12 col-sm-2 about color-gray">
                <h5>Tentang kami</h5>
                <ul>
                    <li><a href="#">Tentang kami</a> </li>
                    <li><a href="#">Sejarah</a> </li>
                    <li><a href="#"></a>Team</li>
                    <li><a href="#">Lowongan Kerja</a> </li>
                </ul>
            </div>
            <div class="col-xs-12 col-sm-2 how-it-works-links color-gray">
                <h5>Bagaiman Kami Berkerja</h5>
                <ul>
                    <li><a href="#">Pilih Lokasi Pengantaran</a> </li>
                    <li><a href="#">Pilih Restoran</a> </li>
                    <li><a href="#">Pilih Hidangan</a> </li>
                    <li><a href="#">Pembayaran Via Resto Pay</a> </li>
                    <li><a href="#">Tunggu pengiriman</a> </li>
                </ul>
            </div>
            <div class="col-xs-12 col-sm-2 pages color-gray">
                <h5>Halaman</h5>
                <ul>
                    <li><a href="#">Homee</a> </li>
                    <li><a href="#">Resto Partner</a> </li>
                    <li><a href="#">Registrasi</a> </li>
                    <li><a href="#">Hubungi Kami</a> </li>
                </ul>
            </div>
            <div class="col-xs-12 col-sm-3 popular-locations color-gray">
                <h5>Lokasi populer</h5>
                <ul>
                    <li><a href="#">Pekanbaru</a> </li>
                    <li><a href="#">Tembilahan</a> </li>

                </ul>
            </div>
        </div>
        <!-- top footer ends -->
        <!-- bottom footer statrs -->
        <div class="bottom-footer">
            <div class="row">
                <div class="col-xs-12 col-sm-3 payment-options color-gray">
                    <h5>Pilihan Metode Bayar</h5>
                    <ul>
                        <li>
                            <a href="#"> Bayar Tunai atau Resto Pay</a>
                        </li>
                        
                            
                        
                        
                            
                        
                        
                            
                        
                        
                            
                        
                    </ul>

                </div>
                <div class="col-xs-12 col-sm-4 address color-gray">
                    <h5>Address</h5>
                    <p>Inkubator Teknik Informatika <br> Jl. HR. Soebrantas Panam, Simpang Baru, Tampan, Kota Pekanbaru, Riau 28293</p>
                    <h5>Hubungi Kami: <a>080 000012 222</a></h5> </div>
                
                    
                    
                
            </div>
        </div>
        <!-- bottom footer ends -->
    </div>
</footer>
<!-- end:Footer -->