<?php $__env->startSection('main'); ?>
    <section class="contact-page inner-page">
    <div class="container">

                <?php echo $__env->make('marketresto.layout.flash_mesage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('marketresto.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>