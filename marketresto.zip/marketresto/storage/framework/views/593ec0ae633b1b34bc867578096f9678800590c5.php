<?php $__env->startSection('main'); ?>
    <div class="breadcrumb">
        <div class="container">
            <ul>
                <li><a href="#" class="active">Home</a></li>
                <li><a href="#">Search results</a></li>
                <li>Profile</li>
            </ul>
        </div>
    </div>




    <section class="contact-page inner-page">
        <div class="container">
            <div class="row">
                <!-- REGISTER -->
                <div class="col-md-8">

                    <?php echo $__env->make('marketresto.layout.flash_mesage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('marketresto.layout.Error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="widget">
                        <div class="widget-body">

                            <?php echo Form::open(['url'=>'register','files'=>true]); ?>


                                <div class="form-group">
                                    <?php echo Form::label('restoran_pemilik_nama','Nama Pemilik',['class'=>'control-label']); ?>

                                    <?php echo Form::text('restoran_pemilik_nama',null,['class' =>'form-control','placeholder' =>'Nama lengkap pemilik']); ?>

                                    <small class="form-text text-muted"></small> </div>
                                <div class="form-group">
                                    <?php echo Form::label('restoran_pemilik_email','Email Pemilik',['class'=>'control-label']); ?>

                                    <?php echo Form::email('restoran_pemilik_email',null,['class' =>'form-control','placeholder' =>'Alamat email aktif']); ?>

                                    <small class="form-text text-muted"></small> </div>
                                <div class="form-group">
                                    <?php echo Form::label('restoran_pemilik_phone','Nomor Ponsel',['class'=>'control-label']); ?>

                                    <?php echo Form::text('restoran_pemilik_phone',null,['class' =>'form-control','placeholder' =>'contoh : 628126847543x']); ?>

                                    <small class="form-text text-muted"></small> </div>


                                
                                    
                                        
                                            
                                                
                                                     
                                                
                                                     
                                                        
                                                         <div class="form-group">
                                                             <label for="exampleInputEmail1">Nama Restoran</label>
                                                            <?php echo Form::text('restoran_nama',null,['class' =>'form-control','placeholder' =>'contoh : RM Mak Icun, KFC Sudirman']); ?>

                                                            <small class="form-text text-muted"></small>
                                                         </div>
                                                         <div class="form-group">
                                                            <label for="exampleInputEmail1">Nomor Ponsel Restoran</label>
                                                            <?php echo Form::text('restoran_phone',null,['class' =>'form-control','placeholder' =>'contoh : 628126847543x']); ?>

                                                            <small class="form-text text-muted text-danger">Pastikan nomor ini aktif ! Nomor ini digunakan untuk mengakses Aplikasi RestoPartner</small>
                                                         </div>
                                                         <div class="form-group">
                                                            <label for="exampleInputEmail1">Alamat Email Restoran</label>
                                                            <?php echo Form::email('restoran_email',null,['class' =>'form-control','placeholder' =>'Alamat email restoran aktif']); ?>

                                                            <small class="form-text text-muted"></small> </div>
                                                         <div class="form-group">
                                                            <label for="exampleTextarea">Alamat Restoran</label>
                                                            <?php echo Form::textarea('restoran_alamat',null,['class' =>'form-control','placeholder' =>'Alamat Lengkap Restoran', 'rows'=>'3']); ?>


                                                         </div>
                                                         <div class="form-group">
                                                            <label for="exampleTextarea">Deskripsi Restoran</label>
                                                            <?php echo Form::textarea('restoran_deskripsi',null,['class' =>'form-control','placeholder' =>'Deskripsi Mengenai Restoran', 'rows'=>'3']); ?>


                                                         </div>

                                                         <div class="form-group">
                                                            <label for="exampleSelect1">Metode Tarif Pengantaran</label>
                                                           <?php echo Form::select('restoran_delivery', ['gratis' => 'Gratis', 'flat' => 'Flat'],null,['class' =>'form-control','placeholder' => 'Pilih Metode','onchange'=>'yesnoCheck(this);']); ?>

                                                         </div>

                                                         <div class="form-group" id="ifYes" style="display: none;">
                                                            <label for="exampleInputEmail1">Biaya Antar</label>
                                                            <?php echo Form::text('restoran_delivery_tarif',0,['class' =>'form-control','placeholder' =>'contoh :5000']); ?>

                                                            <small class="form-text text-muted"></small> </div>

                                                         <div class="form-group ">
                                                            <label for="exampleInputEmail1">Jarak Maksimum Pengantaran</label>
                                                            <?php echo Form::text('restoran_delivery_jarak',null,['class' =>'form-control','placeholder' =>'contoh : 2']); ?>

                                                            <small class="form-text text-muted">KM</small> </div>
                                                         <div class="form-group">
                                                            <label for="exampleInputEmail1">Minimum Pembelian</label>
                                                            <?php echo Form::text('restoran_delivery_minimum',null,['class' =>'form-control','placeholder' =>'contoh : 20000']); ?>

                                                            <small class="form-text text-muted"></small> </div>
                                                         <div class="form-group">
                                                            <label for="exampleInputEmail1">Kategori Menu</label><br>
                                                            <?php echo Form::select('restoran_kategori[]', $kategori,null,['class' =>'select2 select2-multiple form-control', 'style'=>'width:100%','multiple'=>'multiple','data-placeholder' => 'Cari dan Pilih Menu']); ?>

                                                         </div>

                                                         <div class="form-group">
                                                            <label for="exampleInputFile">Foto Logo/Restoran</label>
                                                            <?php echo Form::file('restoran_foto',['class' =>'form-control-file']); ?>

                                                            
                                                         </div>

                                                     
                                                
                                            

                                        
                                    
                                

                            
                                <input class="btn theme-btn" type="submit" value="Submit">
                                


                            </form>
                            <?php echo Form::close(); ?>






                        </div>
                    </div>
                    <!-- end: Widget -->
                </div>
                <!-- /REGISTER -->
                <!-- WHY? -->
                <!-- REGISTER -->





                <div class="col-md-4">
                    <h4>Registration is fast, easy, and free.</h4>
                    <p>Once you"re registered, you can:</p>
                    <hr> <img src="http://placehold.it/400x300" alt="" class="img-fluid">
                    <p></p>
                    <div class="panel">
                        <div class="panel-heading">
                            <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse" class="panel-toggle collapsed" href="#open1" aria-expanded="false"><i class="ti-info-alt" aria-hidden="true"></i>Can I viverra sit amet quam eget lacinia?</a></h4> </div>
                        <div class="panel-collapse collapse" id="open1" aria-expanded="false" role="article" style="height: 0px;">
                            <div class="panel-body"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam rutrum ut erat a ultricies. Phasellus non auctor nisi, id aliquet lectus. Vestibulum libero eros, aliquet at tempus ut, scelerisque sit amet nunc. Vivamus id porta neque, in pulvinar ipsum. Vestibulum sit amet quam sem. Pellentesque accumsan consequat venenatis. Pellentesque sit amet justo dictum, interdum odio non, dictum nisi. Fusce sit amet turpis eget nibh elementum sagittis. Nunc consequat lacinia purus, in consequat neque consequat id. </div>
                        </div>
                    </div>
                    <!-- end:panel -->
                    <div class="panel">
                        <div class="panel-heading">
                            <h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse" class="panel-toggle" href="open2" aria-expanded="true"><i class="ti-info-alt" aria-hidden="true"></i>Can I viverra sit amet quam eget lacinia?</a></h4> </div>
                        <div class="panel-collapse collapse" id="open2" aria-expanded="true" role="article">
                            <div class="panel-body"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam rutrum ut erat a ultricies. Phasellus non auctor nisi, id aliquet lectus. Vestibulum libero eros, aliquet at tempus ut, scelerisque sit amet nunc. Vivamus id porta neque, in pulvinar ipsum. Vestibulum sit amet quam sem. Pellentesque accumsan consequat venenatis. Pellentesque sit amet justo dictum, interdum odio non, dictum nisi. Fusce sit amet turpis eget nibh elementum sagittis. Nunc consequat lacinia purus, in consequat neque consequat id. </div>
                        </div>
                    </div>
                    <!-- end:Panel -->
                    <h4 class="m-t-20">Contact Customer Support</h4>
                    <p> If you"re looking for more help or have a question to ask, please </p>
                    <p> <a href="contact.html" class="btn theme-btn m-t-15">contact us</a> </p>
                </div>
                <!-- /WHY? -->
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('src'); ?>
     <script  type="text/javascript">






        $(document).ready(function() {

            var postURL = "<?php echo url('addmore'); ?>";

            var i = 1;
            var x = 1;


            $('#add').click(function () {

                i++;
                x++;

                $('#dynamic_field').append('<tr id="row' + i + '" class="dynamic-added"><td> ' +

                    '<div class="panel" >' +
                    '<div class="panel-heading">' +
                    '<h4 class="panel-title"><a data-parent="#accordion" data-toggle="collapse" class="panel-toggle collapsed" href="#faq'+i+'" aria-expanded="false"><i class="ti-info-alt" aria-hidden="true"></i>Outlet </a></h4> </div>' +
                    '<div class="panel-collapse collapse" id="faq'+i+'" aria-expanded="false" role="article" style="height: 0px;">' +
                    '<div class="panel-body">' +
                    '<div class="form-group">' +
                    '<label for="exampleInputEmail1">Nama Restoran</label>' +
                    '<?php echo Form::text('restoran_nama[]',null,['class' =>'form-control','placeholder' =>'contoh : RM Mak Icun, KFC Sudirman']); ?>' +
                    '<small class="form-text text-muted"></small>' +
                    '</div>' +
                    '<div class="form-group">' +
                    '   <label for="exampleInputEmail1">Nomor Ponsel Restoran</label>' +
                    '<?php echo Form::text('restoran_phone[]',null,['class' =>'form-control','placeholder' =>'contoh : 628126847543x']); ?>' +
                    '<small class="form-text text-muted text-danger">Pastikan nomor ini aktif ! Nomor ini digunakan untuk mengakses Aplikasi RestoPartner</small>' +
                    '</div>' +
                    '<div class="form-group">' +
                    '   <label for="exampleInputEmail1">Alamat Email Restoran</label>' +
                    '<?php echo Form::email('restoran_email[]',null,['class' =>'form-control','placeholder' =>'Alamat email restoran aktif']); ?>' +
                    '<small class="form-text text-muted"></small> </div>' +
                    '<div class="form-group">' +
                    '   <label for="exampleTextarea">Alamat Restoran</label>' +
                    '<?php echo Form::textarea('restoran_alamat[]',null,['class' =>'form-control','placeholder' =>'Alamat Lengkap Restoran', 'rows'=>'3']); ?>' +

                    '</div>' +
                    '<div class="form-group">' +
                    '   <label for="exampleTextarea">Deskripsi Restoran</label>' +
                    '<?php echo Form::textarea('restoran_deskripsi[]',null,['class' =>'form-control','placeholder' =>'Deskripsi Mengenai Restoran', 'rows'=>'3']); ?>' +

                    '</div>' +

                    ' <div class="form-group">' +
                    '    <label for="exampleSelect1">Metode Tarif Pengantaran</label>' +
                    '<?php echo Form::select('restoran_delivery[]', ['gratis' => 'Gratis', 'flat' => 'Flat'],null,['class' =>'form-control','placeholder' => 'Pilih Metode','onchange'=>'yesnoCheck(this);']); ?>' +
                    '</div>' +

                    '<div class="form-group" id="ifYes" style="display: none;">' +
                    '   <label for="exampleInputEmail1">Biaya Antar</label>' +
                    '<?php echo Form::text('restoran_delivery_tarif[]',0,['class' =>'form-control','placeholder' =>'contoh :5000']); ?>' +
                    '<small class="form-text text-muted"></small> </div>' +

                    '<div class="form-group ">' +
                    ' <label for="exampleInputEmail1">Jarak Maksimum Pengantaran</label>' +
                    '<?php echo Form::text('restoran_delivery_jarak[]',null,['class' =>'form-control','placeholder' =>'contoh : 2']); ?>' +
                    '<small class="form-text text-muted">KM</small> </div>' +
                    '<div class="form-group">' +
                    '<label for="exampleInputEmail1">Minimum Pembelian</label>' +
                    '<?php echo Form::text('restoran_delivery_minimum[]',null,['class' =>'form-control','placeholder' =>'contoh : 20000']); ?>' +
                    ' <small class="form-text text-muted"></small> </div>' +
                    ' <div class="form-group">' +
                    '  <label for="exampleInputEmail1">Kategori Menu</label><br>' +
                    '<?php echo Form::select('restoran_kategori[][]', $kategori,null,['class' =>'select2 select2-multiple form-control', 'style'=>'width:100%','multiple'=>'multiple','data-placeholder' => 'Cari dan Pilih Menu']); ?>' +
                    '</div>' +

                    '<div class="form-group">' +
                    ' <label for="exampleInputFile">Foto Logo/Restoran</label>' +
                    '<?php echo Form::file('restoran_foto[]',['class' =>'form-control-file']); ?>' +

                    '</div>' +

                    '</div>' +
                    '</div>' +
                    '</div>' +

                    ' </td>' +

                    '</tr>');

            });


            $(document).on('click', '.btn_remove', function () {


                var button_id = $(this).attr("id");
                x--;

                $('#row' + button_id + '').remove();
            });

        });


    </script>


     <script > function yesnoCheck(that) {
             if (that.value == "flat") {
                 // alert("check");
                 document.getElementById("ifYes").style.display = "block";
             } else {
                 document.getElementById("ifYes").style.display = "none";
             }
         }</script>

    <?php $__env->stopSection(); ?>






<?php echo $__env->make('marketresto.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>