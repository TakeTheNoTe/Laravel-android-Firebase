<?php

function convert_to_rupiah($angka)
{
    $agk =   substr($angka, 0, -3);
    return       'Rp.'.strrev(implode('.',str_split(strrev(strval($agk)),3)));
}

function to_rupiah($angka)
{

    return       'Rp.'.strrev(implode('.',str_split(strrev(strval($angka)),3)));
}


?>

<?php $__env->startSection('main'); ?>

    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark">Order</h5>
        </div>
        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
                <li class="active"><span>Order</span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>



    <div class="row">
        <div class="col-sm-12">

            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h5 class="txt-dark">Daftar Rekomendasi</h5>
                    </div>

                    <div class="clearfix"></div>
                </div>

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="">
                                <?php if($order_list->count() > 0): ?>
                                    <table id="myTable1" class="table table-hover display  pb-30" >
                                        <thead>
                                        <tr>
                                            <th data-sort-initial="true" data-toggle="true">ID</th>
                                            <th>Nama Konsumen</th>
                                            <th>Nama Restoran</th>
                                            <th>Order LatLang</th>
                                            <th>Alamat</th>
                                            <th>Catatan</th>
                                            <th>Mtode Bayar</th>
                                            <th>Jarak Antar</th>
                                            <th>Biaya Antar</th>
                                            <th>Status</th>
                                            <th>Aksi</th>
                                        </tr>
                                        </thead>
                                        
                                        
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        
                                        
                                        <tbody>
                                        <?php foreach ($order_list as $order):?>


                                        <?php echo csrf_field(); ?>
                                        <tr>
                                            <td><?php echo e($order->id); ?></td>
                                            <td><?php echo e($order->konsumen->konsumen_nama); ?></td>
                                            <td><?php echo e($order->restoran->restoran_nama); ?></td>
                                            <td><?php echo e($order->order_lat); ?><br>
                                            <?php echo e($order->order_long); ?></td>
                                            <td><?php echo e($order->order_alamat); ?></td>
                                            <td><?php echo e(!empty($order->order_catatan) ? $order->order_catatan :'-'); ?></td>
                                            <td>
                                                <?php if($order->order_metode_bayar == 'cash'): ?>
                                                    <span class="label label-primary">Cash</span>
                                                <?php else: ?>
                                                    <span class="label label-danger">epay</span>
                                                <?php endif; ?></td>
                                            </td>
                                            <td><?php echo e($order->order_jarak_antar); ?> Km</td>
                                            <?php
                                            $total =0;
                                            foreach ($order->order_detail as $item):
                                                $total = $total+($item->pivot->qty*($item->pivot->harga-($item->pivot->harga*($item->pivot->discount/100))));
                                            endforeach;
                                            $total = $total + $order->order_biaya_anatar;
                                            ?>
                                            <td><?php echo to_rupiah($total) ?></td>
                                            <td><?php echo e($order->order_status); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('detail_order', $order->id)); ?>" method="GET" style ='float: left; padding-top: 30px' >
                                                    <?php echo e(csrf_field()); ?>

                                                    <button type="submit"  class="btn btn-success btn-xs" >Detail Order</button>
                                                </form>
                                            </td>
                                        </tr>
                                        <?php endforeach ?>
                                        </tbody>
                                    </table>

                                <?php else: ?>
                                    <p> Tidak Ada Kategori</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base_template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>