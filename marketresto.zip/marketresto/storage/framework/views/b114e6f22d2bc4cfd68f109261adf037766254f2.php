<?php $__env->startSection('main'); ?>
    <!-- start: Inner page hero -->

    <section class="bg-image space-md" data-image-src="<?php echo e(asset('marketresto/images/haryo-setyadi-1105368-unsplash.jpg')); ?>">
        <div class="profile">
            <div class="container">
                <div class="row">
                    <div class="col-xs-12 col-sm-4  col-lg-4 profile-img">
                        <h1 class="font-white">Hubungi Kami</h1> </div>
                </div>
            </div>
        </div>
    </section>
    <!-- end:Inner page hero -->
    <div class="breadcrumb">
        <div class="container">
            <ul>
                <li><a href="#" class="active">Home</a></li>
                
                <li>Kontak</li>
            </ul>
        </div>
    </div>
    <section class="contact-page inner-page">
        <div class="container">
            <div class="row">
                <!-- REGISTER -->
                <div class="col-md-8">

                    <?php echo $__env->make('marketresto.layout.flash_mesage', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <?php echo $__env->make('marketresto.layout.Error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                    <div class="widget">
                        <div class="widget-body">
                            <!-- Contact form -->

                            <?php echo Form::open(['url'=>'contact']); ?>


                                <fieldset>
                                    <div class="row form-group">
                                        <div class="col-xs-6">

                                            <?php echo Form::text('nama',null,['class' =>'form-control','placeholder' =>'Nama *']); ?>

                                        </div>
                                        <div class="col-xs-6">
                                            <?php echo Form::text('kota',null,['class' =>'form-control','placeholder' =>'Kota *']); ?>

                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-xs-6">
                                            <?php echo Form::text('email',null,['class' =>'form-control','placeholder' =>'Alamt Email *']); ?>

                                        </div>
                                        <div class="col-xs-6">
                                            <?php echo Form::text('phone',null,['class' =>'form-control','placeholder' =>'Nomor Telepon *']); ?>

                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-xs-12">
                                            <?php echo Form::text('subjek',null,['class' =>'form-control','placeholder' =>'Subjek *']); ?>

                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-xs-12">

                                            <?php echo Form::textarea('pesan',null,['class' =>'form-control','rows'=>'10','placeholder' =>'Pesan *']); ?>

                                        </div>
                                    </div>
                                    <div class="row form-group">
                                        <div class="col-xs-12">
                                            <Input class="btn btn-lg theme-btn" type="submit" value="kirim Pesan">
                                        </div>
                                    </div>
                                </fieldset>
                        <?php echo Form::close(); ?>

                            <!-- End Contact form -->
                        </div>
                    </div>
                    <!-- end: Widget -->
                </div>
                <!-- /REGISTER -->

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('marketresto.layout.template ', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>