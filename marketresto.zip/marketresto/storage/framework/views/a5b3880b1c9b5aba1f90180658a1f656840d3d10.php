<?php if(\Illuminate\Support\Facades\Session::has('flash_error')): ?>
    <div class="alert alert-danger <?php echo e(\Illuminate\Support\Facades\Session::has('penting') ?  'alert-important' : ''); ?>">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <?php echo e(\Illuminate\Support\Facades\Session::get('flash_error')); ?>

    </div>
<?php endif; ?>