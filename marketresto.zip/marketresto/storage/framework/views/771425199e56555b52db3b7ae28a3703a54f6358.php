<?php $__env->startSection('src'); ?>
    <link href="<?php echo e(asset('vendors/bower_components/datatables.net-responsive/css/responsive.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php $__env->stopSection(); ?>

<?php

function convert_to_rupiah($angka)
{
    return 'Rp. '.strrev(implode('.',str_split(strrev(strval($angka)),3)));
}


?>

<?php $__env->startSection('main'); ?>

    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark">Registrasi Baru</h5>
        </div>
        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="index.html">Dashboard</a></li>
                <li><a href="#"><span>speciality pages</span></a></li>
                <li class="active"><span>blank page</span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>



    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h5 class="txt-dark">Daftar Restoran Baru</h5>
                    </div>

                    <div class="clearfix"></div>
                </div>

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="">
                                <?php if($restoran_list->count() > 0): ?>
                                <table id="myTable1" class="table table-hover display  pb-30" >
                                    <thead>
                                    <tr>
                                        <th data-sort-initial="true" data-toggle="true">ID</th>
                                        <th>tgl</th>
                                        <th >Nama Restoran</th>
                                        <th data-sorting="false">Foto</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th data-sorting="false" data>Alamat</th>
                                        <th data-sorting="false">Deskripsi</th>
                                        <th data-sorting="false">Tipe Delivery</th>
                                        <th data-sorting="false"> Tarif Delivery</th>
                                        <th data-sorting="false">Minimum Order</th>
                                        <th data-sorting="false">Jarak Maksimum</th>
                                        <th data-sorting="false">Tipe Menu</th>
                                        <th></th>
                                    </tr>
                                    </thead>
                                    <tfoot>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tgl</th>
                                        <th>Nama Restoran</th>
                                        <th>Foto</th>
                                        <th>Phone</th>
                                        <th>Email</th>
                                        <th>Alamat</th>
                                        <th>Deskripsi</th>
                                        <th>Tipe Delivery</th>
                                        <th>Tarif Delivery</th>
                                        <th>Minimum Order</th>
                                        <th>Jarak Maksimum</th>
                                        <th>Tipe Menu</th>
                                        <th></th>
                                    </tr>
                                    </tfoot>
                                    <tbody>
                                    <?php foreach ($restoran_list as $restoran):?>


                                    <?php echo csrf_field(); ?>
                                    <tr>
                                        <td><?php echo e($restoran->id); ?></td>
                                        <td><?php echo e($restoran->created_at->format('d/m/Y H:m:s')); ?></td>
                                        <td><strong><?php echo e($restoran->restoran_nama); ?></strong></td>
                                        <td><img src="<?php echo e(asset('fotorestoran/'.$restoran->restoran_foto)); ?>" alt="<?php echo e($restoran->restoran_foto); ?>" width="70" height="95"></td>
                                        <td><?php echo e($restoran->restoran_phone); ?></td>
                                        <td><?php echo e($restoran->restoran_email); ?></td>
                                        <td><?php echo e($restoran->restoran_alamat); ?></td>
                                        <td><?php echo e($restoran->restoran_deskripsi); ?></td>

                                        <td> <?php if($restoran->restoran_delivery == 'gratis'): ?>
                                                <span class="label label-warning"><?php echo e($restoran->restoran_delivery); ?></span>
                                             <?php else: ?>
                                                <span class="label label-success"><?php echo e($restoran->restoran_delivery); ?></span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php if($restoran->restoran_delivery_tarif == 0): ?>
                                               Gratis </span>
                                            <?php else: ?>
                                                <?php echo e($restoran->restoran_delivery_tarif); ?>

                                            <?php endif; ?></td>
                                        <td><?php echo convert_to_rupiah($restoran->restoran_delivery_minimum)?></td>
                                        <td><?php echo e($restoran->restoran_delivery_jarak); ?></td>
                                        <td>
                                            <?php $__currentLoopData = $restoran->kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <strong><span><?php echo e($kategori->kategori_nama); ?>,</span></strong>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>


                                            <form action="<?php echo e(route('updateRegistrasi', $restoran->id)); ?>" method="POST" style ='float: left; padding-top: 30px' >
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('PATCH')); ?>

                                                <input type="hidden" name="restoran_status" value="aktif">
                                                <button type="submit"  class="btn btn-success" >Terima</button>
                                            </form>

                                            <form action="<?php echo e(route('updateRegistrasi', $restoran->id)); ?>" method="POST" style ='float: left;padding-top: 30px' >
                                                <?php echo e(csrf_field()); ?>

                                                <?php echo e(method_field('PATCH')); ?>

                                                <input type="hidden" name="restoran_status" value="tolak">
                                                <button type="submit" class="btn btn-danger" >Tolak </button>
                                            </form>

                                        </td>
                                    </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>

                                    <?php else: ?>
                                <p> Tidak Ada Registrasi</p>
                                    <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/responsive-datatable-data.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base_template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>