<?php $__env->startSection('main'); ?>
    <section class="contact-page inner-page">
    <div class="container">
    <div class="panel panel-success card-view">
        <div class="panel-heading">
            <div class="pull-left">
                <h6 class="panel-title txt-light">Success</h6>
            </div>
            <div class="clearfix"></div>
        </div>
        <div  class="panel-wrapper collapse in">
            <div  class="panel-body">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vestibulum tincidunt est vitae ultrices accumsan. Aliquam ornare lacus adipiscing, posuere lectus et, fringilla augue.</p>
            </div>
        </div>
    </div>
    </div>
    </section>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('marketresto.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>