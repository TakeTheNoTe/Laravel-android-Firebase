<?php

function convert_to_rupiah($angka)
{
    $agk =   substr($angka, 0, -3);
    return       'Rp. '.strrev(implode('.',str_split(strrev(strval($agk)),3)));
}


?>

<?php $__env->startSection('main'); ?>

    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark">Riwayat Transaksi Restopay</h5>
        </div>
        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
                <li class="active"><span>Riwayat Restopay</span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>



    <div class="row">
        <div class="col-sm-12">

            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h5 class="txt-dark">Daftar Riwayat</h5>
                    </div>


                    <div class="clearfix"></div>
                </div>

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="">
                                <?php if($riwayat_list->count() > 0): ?>
                                    <table id="myTable1" class="table table-hover display  pb-30" >
                                        <thead>
                                        <tr>
                                            <th data-sort-initial="true" data-toggle="true">ID</th>
                                            <th>Penerima</th>
                                            <th>Nominal</th>
                                            <th>Pengirim</th>
                                            <th>Jenis Transaksi</th>
                                            <th>Tgl Transaksi</th>
                                            
                                        </tr>
                                        </thead>
                                        
                                        
                                            
                                            
                                            
                                            
                                            
                                        
                                        
                                        <tbody>
                                        <?php foreach ($riwayat_list as $riwayat):?>


                                        <?php echo csrf_field(); ?>
                                        <tr>
                                            <td><?php echo e($riwayat->id); ?></td>
                                            <td>+<?php echo e($riwayat->penerima_phone); ?> - <?php echo e($riwayat->penerima_tipe); ?></td>
                                            <td><?php echo convert_to_rupiah($riwayat->nominal)?></td>
                                            <td><?php echo e($riwayat->pengirim_tipe); ?></td>
                                            <td>
                                            <?php if($riwayat->jenis_transaksi == 'topup'): ?>
                                                <span class="label label-warning"><?php echo e($riwayat->jenis_transaksi); ?></span>
                                            <?php else: ?>
                                                <span class="label label-primary"><?php echo e($riwayat->jenis_transaksi); ?></span>
                                            <?php endif; ?>
                                            </td>
                                            <td><?php echo e($riwayat->created_at->format('d/m/Y H:m:s')); ?></td>
                                            
                                                
                                                    
                                                    
                                                
                                            
                                        </tr>
                                        <?php endforeach ?>
                                        </tbody>
                                    </table>

                                <?php else: ?>
                                    <p> Tidak Ada Rekomendasi</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base_template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>