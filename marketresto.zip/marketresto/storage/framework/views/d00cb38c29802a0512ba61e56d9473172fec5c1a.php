<?php $__env->startSection('src'); ?>
    <link href="<?php echo e(asset('vendors/bower_components/datatables.net-responsive/css/responsive.dataTables.min.css')); ?>" rel="stylesheet" type="text/css"/>
    <?php $__env->stopSection(); ?>

<?php

function convert_to_rupiah($angka)
{
    $agk =   substr($angka, 0, -3);
    return       'Rp. '.strrev(implode('.',str_split(strrev(strval($agk)),3)));
}

function to_rupiah($angka)
{

    return       'Rp. '.strrev(implode('.',str_split(strrev(strval($angka)),3)));
}


?>

<?php $__env->startSection('main'); ?>

    <div class="row heading-bg">
        <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
            <h5 class="txt-dark">Registrasi Baru</h5>
        </div>
        <!-- Breadcrumb -->
        <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
            <ol class="breadcrumb">
                <li><a href="<?php echo e(url('/admin')); ?>">Dashboard</a></li>
                <li class="active"><span>Menu</span></li>
            </ol>
        </div>
        <!-- /Breadcrumb -->
    </div>



    <div class="row">
        <div class="col-sm-12">
            <div class="panel panel-default border-panel card-view">
                <div class="panel-heading">
                    <div class="pull-left">
                        <h5 class="txt-dark">Daftar Restoran Baru</h5>
                    </div>

                    <div class="clearfix"></div>
                </div>

                <div class="panel-wrapper collapse in">
                    <div class="panel-body">
                        <div class="table-wrap">
                            <div class="">
                                <?php if($order->order_detail ->count() > 0): ?>
                                <table id="myTable1" class="table table-hover display  pb-30" >
                                    <thead>
                                    <tr>

                                        <th >Nama Menu</th>
                                        <th >Kategori</th>
                                        <th data-sorting="false">Foto</th>
                                        <th>Menu Harga</th>
                                        <th data-sorting="false">Discount(@)</th>
                                        <th data-sorting="false">Qty</th>
                                        <th data-sorting="false">Total</th>
                                    </tr>
                                    </thead>

                                    <tbody>
                                    <?php foreach ($order->order_detail  as $menu):?>


                                    <?php echo csrf_field(); ?>
                                    <tr>

                                        <td><?php echo e($menu->menu_nama); ?></td>
                                        <td><?php echo e($menu->kategori->kategori_nama); ?></td>
                                        <td><img src="<?php echo e(asset('fotomenu/'.$menu->menu_foto)); ?>" alt="<?php echo e($menu->menu_foto); ?>" width="70" height="95"></td>
                                        <td><?php echo e($menu->pivot->harga); ?></td>
                                        <td> <?php if($menu->pivot->discount == '0.00'): ?>
                                              -
                                             <?php else: ?>
                                                <span class="label label-default"><?php echo e($menu->pivot->discount); ?> %</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($menu->pivot->qty); ?></td>
                                        <td><?php echo to_rupiah($menu->pivot->qty * ($menu->pivot->harga - ($menu->pivot->harga * ($menu->pivot->discount/100))))?></td>


                                    </tr>
                                    <?php endforeach ?>
                                    </tbody>
                                </table>

                                    <?php else: ?>
                                <p> Tidak Ada Registrasi</p>
                                    <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>





<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('vendors/bower_components/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('vendors/bower_components/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/dist/js/responsive-datatable-data.js')); ?>"></script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.base_template_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>