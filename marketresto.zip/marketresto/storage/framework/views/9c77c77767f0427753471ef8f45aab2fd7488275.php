<!--header starts-->
<header id="header" class="header-scroll top-header headrom">
    <!-- .navbar -->
    <nav class="navbar navbar-dark">
        <div class="container">
            <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#mainNavbarCollapse">&#9776;</button>
            <a class="navbar-brand" href="index.html"> <img class="img-rounded" src="<?php echo e(asset('marketresto/images/text-logo-medium.png')); ?>" alt=""> </a>
            <div class="collapse navbar-toggleable-md  float-lg-right" id="mainNavbarCollapse">
                <ul class="nav navbar-nav">
                    
                    <?php if(empty($halaman)): ?>
                        <li class="nav-item"> <a class="nav-link active" href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a> </li>
                    <?php else: ?>
                        <li class="nav-item"> <a class="nav-link " href="<?php echo e(url('/')); ?>">Home <span class="sr-only">(current)</span></a> </li>
                    <?php endif; ?>
                    
                    <?php if(!empty($halaman) && $halaman == 'daftar'): ?>
                        <li class="nav-item"> <a class="nav-link active" href="<?php echo e(url('/daftar')); ?>">Restoran Partner <span class="sr-only">(current)</span></a> </li>
                    <?php else: ?>
                        <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/daftar')); ?>">Restoran Partner <span class="sr-only">(current)</span></a> </li>
                    <?php endif; ?>
                    
                    <?php if(!empty($halaman) && $halaman == 'contact'): ?>
                        <li class="nav-item "> <a class="nav-link active" href="<?php echo e(url('/contact')); ?>">Hubungi Kami<span class="sr-only">(current)</span></a> </li>
                    <?php else: ?>
                        <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('/contact')); ?>">Hubungi Kami<span class="sr-only">(current)</span></a> </li>
                    <?php endif; ?>
                    
                        
                            
                    
                </ul>
            </div>
        </div>
    </nav>
    <!-- /.navbar -->
</header>